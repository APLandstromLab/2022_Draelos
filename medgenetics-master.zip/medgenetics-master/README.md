# Requirements

Python 3.5.1
See requirements.txt for packages